<!-- Navigation Bar -->
<nav class="navigation">
    <ul>
        <li><a href="../dashboard.php">Dashboard</a></li>
        <li><a href="../vendors/vendor.php">Vendor</a></li>
        <li><a href="../inventory/inventory.php">Inventory Management</a></li>
        <li><a href="../procurement/procurement.php">Procurement Request</a></li>
        <li><a href="../report/report.php">Report</a></li>
        <li><a href="../order/read_orders.php">Purchase Orders</a></li>
        <li><a href="../logout.php">Log Out</a></li>
    </ul>
</nav>
