<footer>
        All right reserved © 2025 Secure AMC System
    </footer>
</body>
</html>
