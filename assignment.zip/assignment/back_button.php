<!-- Back Button -->
<div class="back-button-container" style="margin-top: 20px; text-align: center; padding-left: 20px;">
    <button onclick="history.back()" class="btn btn-secondary">Go Back</button>
</div>
